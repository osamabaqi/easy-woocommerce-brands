﻿=== Easy Woocommerce Brands ===
Contributors: osamabaqi123, iamshehryar
Tags: brand, brands, logo, manufacturer, woocommerce brands
Requires at least: 5.0
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
The Easy Woocommerce Brands plugin allows you to create brands for your shop. In this plugin you manage a brand can be named, described, image and assigned to a products.
 
== Description ==
 
Easy Woocommerce Brands plugin allow you to add brands to your WooCommerce products on your website with any WordPress theme.
 
= Features =

Easy Woocommerce Brands plugin allow you to add brands to your WooCommerce products on your website with any WordPress theme


*	Easy to use and 100% Free.
*	Lightweight plugin
*	Add unlimited Brands 
*	Assign multiple brands to your one product.
*	Display brand name, images and both on a Product page.
*	Brands Widget.
*	Display all brands on page using shortcode.
*	100% Responsive design
*	Add logos to your brands.
*	Custom Permalink.
*	Brand image Width and Height.
*	Custom Brand Position.


== Installation ==

1. Upload easy-woocommerce-brands plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
 
== Frequently Asked Questions ==
 
= How to Choose Brand Style =
 
*	Go the the ‘Product->EWB Setting’ 
*	Choose style of the brand (Text/ Image)
 
= What about Style 1 (Text)? =
 
If you choose text style that's means, you show a brands name on a single product page. (Example: Brands: Iphone, Samsung, Nokia)

= What about Style 2 (Image)? =
 
If you choose Image style that's means, you show a brand images on a single product page. (Example: Brands: Iphone(Image), Samsung(Image), Nokia(Image))
 
= What about Style 3 (Both)? =
 
If you choose Both style that's means, you show a brand name and images on a single product page. 

= How to show brands on a single page? =

You can use this shortcode to display all brands on single page. [easy_woocommerce_brands_page]

It supports Title Parameter to show only Title and Title with Counts or hide Title. You can pass 1, 2 or 3.[easy_woocommerce_brands_page title="1"]
 
== Screenshots ==
 
1. Easy Woocommerce Brands for Style 1(Text).
2. Easy Woocommerce Brands for Style 2(Image).
3. Easy Woocommerce Brands for Style 3(Both).
4. Managing Brands section.
5. Assign brand/brands to product.
6. Settings of Easy woocommerce brand plugin.
7. Widget settings.
8. Display brands widget. 
9. Display all brands on page using shortcode.