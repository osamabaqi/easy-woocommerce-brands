<?php

$ewbct_position_val= esc_attr(get_option('ewbct_position'));

if ($ewbct_position_val == "Below product title") {
    add_action( 'woocommerce_single_product_summary', 'ewbct_action_product_meta_end', 10, 10 );
}
if ($ewbct_position_val == "Below product summary") {
    add_action( 'woocommerce_single_product_summary', 'ewbct_action_product_meta_end', 30  );
}
if ($ewbct_position_val == "Below category list") {
    add_action( 'woocommerce_product_meta_end', 'ewbct_action_product_meta_end' );
}
if ($ewbct_position_val == "Above add to cart") {
    add_action( 'woocommerce_simple_add_to_cart', 'ewbct_action_product_meta_end', 30 );
}
if ($ewbct_position_val == "Below add to cart") {
    add_action( 'woocommerce_after_add_to_cart_button', 'ewbct_action_product_meta_end' );
}
if ($ewbct_position_val == "Above description tabs") {
    add_action( 'woocommerce_after_single_product_summary', 'ewbct_action_product_meta_end', 10  );
}

if (empty($ewbct_position_val)) {
    add_action( 'woocommerce_product_meta_end', 'ewbct_action_product_meta_end' );
}
// Hook taxonomy brand from single product page

function ewbct_action_product_meta_end() {
    
    global $product;
    
    $product_id= $product->get_id();
    
    $ewbct_taxonomy = get_the_terms( $product_id, "ewbrands");


    if (!empty($ewbct_taxonomy)) {
        
        $db_ewbct_style= esc_attr( get_option('ewbct_style') );
        //$db_ewbct_title= esc_attr( get_option('ewbct_title') );

        $db_ewbct_title = (!empty(esc_attr( get_option('ewbct_title')))) ? esc_attr( get_option('ewbct_title') ) : 'BRAND: ';

        if ($db_ewbct_style== "Text") {
            echo "<div class='brand'>";
            if (empty($db_ewbct_title)) {
                $db_ewbct_title= _e("Brands: ", "easy-woocommerce-brands");
            }
            if (!empty($db_ewbct_title)) {
                $db_ewbct_title= _e(get_option('ewbct_title').": ", "easy-woocommerce-brands");
            }
            echo "<span>".$db_ewbct_title."</span>";
            foreach ($ewbct_taxonomy as $tax) {

                echo ("<span><a href=".get_term_link( $tax->term_id, "ewbrands" ).">".$tax->name."</a></span><span class='commas'>,</span> ");
            }
            echo "</div>";
        }

        if ($db_ewbct_style== "Image") {
            echo "<div class='brand'>".esc_attr($db_ewbct_title)." ";
            foreach ($ewbct_taxonomy as $tax) {
                $image_id = get_term_meta ( $tax->term_id, 'ewbct_category-image-id', true );

                echo ("<div class='ewb_logo'><a href=".get_term_link( $tax->term_id, "ewbrands" ).">".wp_get_attachment_image ( $image_id, '20px' )."</a></div>");
            }
            echo "</div>";
        }
        if ($db_ewbct_style== "Both") {
            echo "<div class='brand'>";
                if (empty($db_ewbct_title)) {
                    $db_ewbct_title= _e("Brands: ", "easy-woocommerce-brands");
                }
                if (!empty($db_ewbct_title)) {
                    $db_ewbct_title= _e(get_option('ewbct_title').": ", "easy-woocommerce-brands");
                }
                echo "<span>".$db_ewbct_title."</span>";
                foreach ($ewbct_taxonomy as $tax) {

                    echo ("<span><a href=".get_term_link( $tax->term_id, "ewbrands" ).">".$tax->name."</a></span><span class='commas'>,</span> ");
                }
                echo "</div>";
                echo "<div class='brand'>";
                foreach ($ewbct_taxonomy as $tax) {
                    $image_id = get_term_meta ( $tax->term_id, 'ewbct_category-image-id', true );

                    echo ("<div class='ewb_logo'><a href=".get_term_link( $tax->term_id, "ewbrands" ).">".wp_get_attachment_image ( $image_id, '20px' )."</a></div>");
                }
            echo "</div>";

        }

        if ($db_ewbct_style== "" || empty($db_ewbct_style)) {
            echo "<div class='brand'>".esc_attr($db_ewbct_title);
            foreach ($ewbct_taxonomy as $tax) {
                echo ("<span><a href=".get_term_link( $tax->term_id, "ewbrands" ).">".$tax->name."</a></span><span class='commas'>,</span> ");
            }
            echo "</div>";

        }

    }

}

// Custom Css for single product page
function ewbct_brandscss(){

      $ewbct_width_val= esc_attr(get_option('ewbct_width'));
      $ewbct_height_val= esc_attr(get_option('ewbct_height'));
      $ewbct_image_style_val= esc_attr( get_option('ewbct_image_style') );

      if ($ewbct_width_val != "") {
            $ewbct_width_val= esc_attr(get_option('ewbct_width'));

      }
      if ($ewbct_height_val != "") {
        $ewbct_height_val= esc_attr(get_option('ewbct_height'));
      }

      if ($ewbct_image_style_val=="Rounded") {
          $ewbct_image_style_val = "50%";
      }
      if ($ewbct_image_style_val=="Rectangle") {
          $ewbct_image_style_val = "0px";
      }
      if ($ewbct_width_val == "" || $ewbct_height_val == "") {
          $ewbct_height_val = "30";
          $ewbct_width_val = "70";
      } 

    echo "<style>".$abc.".brand .commas:last-child { display: none; }.brand:nth-last-child(2){ padding-bottom: 20px; }.ewbct_logo { width: 50px; float: left; border: 1px solid #d6d3d3; padding: 4px; height: 30px; }.ewb_logo img { width: ".$ewbct_width_val."px; float: left; border: 1px solid #d8d8d8; padding: 4px; height:  ".$ewbct_height_val."px; border-radius: ".$ewbct_image_style_val."}.brand { padding-top: 15px; width: 100%;   display: flow-root;}.widget ul li { list-style-type: none; }</style>";
}

add_action( 'wp_head', 'ewbct_brandscss' );



// create custom plugin settings menu
add_action('admin_menu', 'ewbct_name_settings_page');
function ewbct_name_settings_page() {
  //create new top-level menu
  add_submenu_page( 'options-general.php', esc_html__('EWB Settings','ewbct_settings'), esc_html__('EWB Settings','ewbct_settings'), 'manage_options', 'ewb_settings', 'ewbct_name_settings_page_render' );

  //call register settings function
  add_action( 'admin_init', 'ewbct_register_name_settings' );
}


function ewbct_register_name_settings() {
  register_setting( 'ewb_setting_group', 'ewbct_style' );
  register_setting( 'ewb_setting_group', 'ewbct_permalink' );
  register_setting( 'ewb_setting_group', 'ewbct_width' );
  register_setting( 'ewb_setting_group', 'ewbct_height' );
  register_setting( 'ewb_setting_group', 'ewbct_position' );
  register_setting( 'ewb_setting_group', 'ewbct_title' );
  register_setting( 'ewb_setting_group', 'ewbct_image_style' );
  register_setting( 'ewb_setting_group', 'ewbct_image_brands_columns' );
}

function ewbct_name_settings_page_render() {
?>
<div class="wrap">
<h1><?php _e("Easy Woocommerce Brands", "easy-woocommerce-brands");?></h1>
<div class="notice">
    <h3><?php _e("Shortcode for brand page:", "easy-woocommerce-brands");?></h3>
    <p><?php _e('You can use this shortcode to display all brands on single page.<b><i> [easy_woocommerce_brands_page]</i></b><br> It supports Title Parameter to show only Title and Title with Counts or hide Title. You can pass 1, 2 or 3.<b><i>[easy_woocommerce_brands_page title="1"]</i></b> ', "easy-woocommerce-brands");?></p><br>
</div>
<h3 style=" font-size: 26px; "><?php _e("Settings", "easy-woocommerce-brands");?></h3><hr>
<form method="post" action="options.php">
    <?php settings_fields( 'ewb_setting_group'); ?>
    <?php do_settings_sections( 'ewb_setting_group'); ?>
    <table class="form-table">
        <tr valign="top">
            <th scope="row"><h4 style=" font-size: 19px; margin: 0px; "><?php _e("Product Page Settings", "easy-woocommerce-brands");?></h4></th>
        </tr>

        <tr valign="top">
            <th scope="row"><?php _e("Title", "easy-woocommerce-brands");?></th>
            <td>
                <?php $db_ewbct_style= esc_attr( get_option('ewbct_title') ); ?>
                    <input type="text" name="ewbct_title"  class="regular-text" value="<?php echo esc_attr(get_option('ewbct_title')); ?>" >
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php _e("Style", "easy-woocommerce-brands");?></th>
            <td>
                <?php $db_ewbct_style= esc_attr( get_option('ewbct_style') ); ?>
                <select name="ewbct_style"  class="regular-text">
                    <option value="Text" <?php selected( $db_ewbct_style, "Text" ); ?>><?php _e("Text", "easy-woocommerce-brands");?></option>
                    <option value="Image" <?php selected( $db_ewbct_style, "Image" ); ?>><?php _e("Image", "easy-woocommerce-brands");?></option>
                    <option value="Both" <?php selected( $db_ewbct_style, "Both" ); ?>><?php _e("Both", "easy-woocommerce-brands");?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php _e("Brand position", "easy-woocommerce-brands");?></th>
            <td>
                <?php $db_ewbct_style= esc_attr( get_option('ewbct_position') ); ?>
                <select name="ewbct_position"  class="regular-text">
                    <option style="display: none;text-align: center;">Select Position</option>
                    <option value="Below product title" <?php selected( $db_ewbct_style, "Below product title" ); ?>><?php _e("Below product title", "easy-woocommerce-brands");?></option>
                    <option value="Below product summary" <?php selected( $db_ewbct_style, "Below product summary" ); ?>><?php _e("Below product summary", "easy-woocommerce-brands");?></option>
                    <option value="Below category list" <?php selected( $db_ewbct_style, "Below category list" ); ?>><?php _e("Below category list", "easy-woocommerce-brands");?></option>
                    <option value="Above add to cart" <?php selected( $db_ewbct_style, "Above add to cart" ); ?>><?php _e("Above add to cart", "easy-woocommerce-brands");?></option>
                    <option value="Below add to cart" <?php selected( $db_ewbct_style, "Below add to cart" ); ?>><?php _e("Below add to cart", "easy-woocommerce-brands");?></option>
                    <option value="Above description tabs" <?php selected( $db_ewbct_style, "Above description tabs" ); ?>><?php _e("Above description tabs", "easy-woocommerce-brands");?></option>
                </select>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php _e("Image width(px)", "easy-woocommerce-brands");?></th>
            <td>
                <?php $db_ewbct_style= esc_attr( get_option('ewbct_width') ); ?>
                    <input type="number" name="ewbct_width"  class="regular-text" value="<?php echo esc_attr(get_option('ewbct_width')); ?>" min="20">
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php _e("Image height(px)", "easy-woocommerce-brands");?></th>
            <td>
                <?php $db_ewbct_style= esc_attr( get_option('ewbct_height') ); ?>
                    <input type="number" name="ewbct_height"  class="regular-text" value="<?php echo esc_attr(get_option('ewbct_height')); ?>" min="20">
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php _e("Image style", "easy-woocommerce-brands");?></th>
            <td>
                <?php $db_ewbct_style= esc_attr( get_option('ewbct_image_style') ); ?>
                <select name="ewbct_image_style"  class="regular-text">
                    <option style="display: none;text-align: center;">Select Image Style</option>
                    <option value="Rounded" <?php selected( $db_ewbct_style, "Rounded" ); ?>><?php _e("Rounded", "easy-woocommerce-brands");?></option>
                    <option value="Rectangle" <?php selected( $db_ewbct_style, "Rectangle" ); ?>><?php _e("Rectangle", "easy-woocommerce-brands");?></option>
                </select>
            </td>
        </tr>


    </table>

    <?php submit_button(); ?>

</form>
</div>
<?php }
?>
