<?php

class ewb_brands_list_widget extends WP_Widget {

	/**
	 * Sets up the widgets name etc
	 */
	public function __construct() {
		$widget_ops = array( 
			'classname' => 'ewbct_brands_list',
			'description' => 'Easy Woocommerce Brands',
		);
		parent::__construct( 'ewb_brands_list', 'Easy Woocommerce Brands - List', $widget_ops );
	}

	/**
	 * Outputs the content of the widget
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {
		
		extract( $args );
		$check_title = (!empty($instance[ 'widget_title' ])) ? $instance[ 'widget_title' ] : 'BRANDS';


		$title = apply_filters('widget_title', $check_title );
		$hide_empty = (!empty($instance[ 'hide_empty' ])) ? $instance[ 'hide_empty' ] : '';
		$show_count = (!empty($instance[ 'show_count' ])) ? $instance[ 'show_count' ] : '';
		$hierarchical = (!empty($instance[ 'hierarchical' ])) ? $instance[ 'hierarchical' ] : '';
		$order = (!empty($instance[ 'order' ])) ? $instance[ 'order' ] : '';
		$depth = (!empty($instance[ 'depth' ])) ? $instance[ 'depth' ] : '';

		echo $before_widget;

			if ( $title ) {
		      echo $before_title . $title . $after_title;
		    }

		    $brandArgs = array(
		    	'show_option_none' => esc_html__('Sorry! No brands are found. Please add brands and assign brands on a products.','easy-woocommerce-brands'),
		    	'taxonomy'=> 'ewbrands',
		    	'title_li'=>'',
		    	'hide_title_if_empty'=> true,
		    	'echo' => 0, 
		    );

		    //hide empty
		    if ($hide_empty == 'no') :
		    	$brandArgs['hide_empty'] = false;
		    else :
		    	$brandArgs['hide_empty'] = true;
		    endif;

		    //show count
		    if ($show_count == 'yes') :
		    	$brandArgs['show_count'] = 1;
		    else :
		    	$brandArgs['show_count'] = 0;
		    endif;

		    //hierarchical
		    if ($hierarchical == 'no') :
		    	$brandArgs['hierarchical'] = false;
		    else :
		    	$brandArgs['hierarchical'] = true;
		    endif;

		    //order
		    if ($order == 'desc') :
		    	$brandArgs['order'] = 'DESC';
		    else :
		    	$brandArgs['order'] = 'ASC';
		    endif;

		    //depth
		    if ($depth == 'yes') :
		    	$brandArgs['depth'] = 1;
		    else :
		    	$brandArgs['depth'] = 0;
		    endif;

			echo "<ul>";
				echo wp_list_categories($brandArgs);
			echo "</ul>";

		echo $after_widget;




	}

	/**
	 * Outputs the options form on admin
	 *
	 * @param array $instance The widget options
	 */
	public function form( $instance ) {
	    $ewbwt_menu_title = (!empty($instance[ 'ewbwt_menu_title' ])) ? $instance[ 'ewbwt_menu_title' ] : '';
	    $hide_empty = (!empty($instance[ 'hide_empty' ])) ? $instance[ 'hide_empty' ] : '';
	    $show_count = (!empty($instance[ 'show_count' ])) ? $instance[ 'show_count' ] : '';
	    $hierarchical = (!empty($instance[ 'hierarchical' ])) ? $instance[ 'hierarchical' ] : '';
	    $order = (!empty($instance[ 'order' ])) ? $instance[ 'order' ] : '';
	    $depth = (!empty($instance[ 'depth' ])) ? $instance[ 'depth' ] : '';
     
	    // markup for form ?>
	    <p>
	        <label for="<?php echo $this->get_field_id( 'ewbwt_menu_title' ); ?>"><?php esc_html_e('Title:','easy-woocommerce-brands'); ?></label>
	        <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'ewbwt_menu_title' ); ?>" name="<?php echo $this->get_field_name( 'ewbwt_menu_title' ); ?>" value="<?php echo esc_attr( $ewbwt_menu_title ); ?>">
	    </p>

	    <p>
	        <label for="<?php echo $this->get_field_id( 'hide_empty' ); ?>"><?php esc_html_e('Hide Empty:','easy-woocommerce-brands'); ?></label>
	        <select class="widefat" id="<?php echo $this->get_field_id( 'hide_empty' ); ?>" name="<?php echo $this->get_field_name( 'hide_empty' ); ?>">
	        	<option value="yes" <?php selected( $hide_empty, "yes" ); ?>><?php esc_html_e('Yes','easy-woocommerce-brands'); ?></option>
	        	<option value="no" <?php selected( $hide_empty, "no" ); ?>><?php esc_html_e('No','easy-woocommerce-brands'); ?></option>
	        </select>
	    </p>

	    <p>
	        <label for="<?php echo $this->get_field_id( 'show_count' ); ?>"><?php esc_html_e('Show Count:','easy-woocommerce-brands'); ?></label>
	        <select class="widefat" id="<?php echo $this->get_field_id( 'show_count' ); ?>" name="<?php echo $this->get_field_name( 'show_count' ); ?>">
	        	<option value="no" <?php selected( $show_count, "no" ); ?>><?php esc_html_e('No','easy-woocommerce-brands'); ?></option>
	        	<option value="yes" <?php selected( $show_count, "yes" ); ?>><?php esc_html_e('Yes','easy-woocommerce-brands'); ?></option>
	        </select>
	    </p>

	    <p>
	        <label for="<?php echo $this->get_field_id( 'hierarchical' ); ?>"><?php esc_html_e('Hierarchical:','easy-woocommerce-brands'); ?></label>
	        <select class="widefat" id="<?php echo $this->get_field_id( 'hierarchical' ); ?>" name="<?php echo $this->get_field_name( 'hierarchical' ); ?>">
	        	<option value="yes" <?php selected( $hierarchical, "yes" ); ?>><?php esc_html_e('Yes','easy-woocommerce-brands'); ?></option>
	        	<option value="no" <?php selected( $hierarchical, "no" ); ?>><?php esc_html_e('No','easy-woocommerce-brands'); ?></option>
	        </select>
	    </p>

	    <p>
	        <label for="<?php echo $this->get_field_id( 'depth' ); ?>"><?php esc_html_e('Show only parent items:','easy-woocommerce-brands'); ?></label>
	        <select class="widefat" id="<?php echo $this->get_field_id( 'depth' ); ?>" name="<?php echo $this->get_field_name( 'depth' ); ?>">
	        	<option value="no" <?php selected( $depth, "no" ); ?>><?php esc_html_e('No','easy-woocommerce-brands'); ?></option>
	        	<option value="yes" <?php selected( $depth, "yes" ); ?>><?php esc_html_e('Yes','easy-woocommerce-brands'); ?></option>
	        </select>
	    </p>

	    <p>
	        <label for="<?php echo $this->get_field_id( 'order' ); ?>"><?php esc_html_e('Order:','easy-woocommerce-brands'); ?></label>
	        <select class="widefat" id="<?php echo $this->get_field_id( 'order' ); ?>" name="<?php echo $this->get_field_name( 'order' ); ?>">
	        	<option value="asc" <?php selected( $order, "asc" ); ?>><?php esc_html_e('ASC','easy-woocommerce-brands'); ?></option>
	        	<option value="desc" <?php selected( $order, "desc" ); ?>><?php esc_html_e('DESC','easy-woocommerce-brands'); ?></option>
	        </select>
	    </p>
             
		<?php 
	}

	/**
	 * Processing widget options on save
	 *
	 * @param array $new_instance The new options
	 * @param array $old_instance The previous options
	 *
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
	    $instance = $old_instance;
	    $instance[ 'ewbwt_menu_title' ] = strip_tags( $new_instance[ 'ewbwt_menu_title' ] );
	    $instance[ 'hide_empty' ] = strip_tags( $new_instance[ 'hide_empty' ] );
	    $instance[ 'show_count' ] = strip_tags( $new_instance[ 'show_count' ] );
	    $instance[ 'hierarchical' ] = strip_tags( $new_instance[ 'hierarchical' ] );
	    $instance[ 'order' ] = strip_tags( $new_instance[ 'order' ] );
	    $instance[ 'depth' ] = strip_tags( $new_instance[ 'depth' ] );
	    return $instance;
	}
}
add_action( 'widgets_init', function(){
	register_widget( 'ewb_brands_list_widget' );
});

?>