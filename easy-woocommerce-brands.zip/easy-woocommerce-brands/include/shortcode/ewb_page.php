<?php

class ewbClass {
	public static function ewb_page_func( $atts, $content = "" ) {
        
        extract( shortcode_atts( array(
            'title'         => 1
        ), $atts ) );

    	$ewbct_custom_taxonomy = get_categories( $arrayName = array('taxonomy' => 'ewbrands' ));
    	$ewbct_count= count($ewbct_custom_taxonomy);
        
        echo "<div class='ewb-page'>";
        	foreach ($ewbct_custom_taxonomy as $ewb_page_loop) {
                echo "<div class='ewb-columns'>";
                    $image_id = get_term_meta ( $ewb_page_loop->term_id, 'ewbct_category-image-id', true );

                    echo ("<div class='ewb_logo_page'><a href=".get_term_link( $ewb_page_loop->term_id, "ewbrands" ).">".wp_get_attachment_image ( $image_id, 'ewb-brand-image-156-62' )."</a></div>");
                    if($title == 1) {
                        echo ("<div class='ewb_text_page'><a href=".get_term_link( $ewb_page_loop->term_id, "ewbrands" ).">".$ewb_page_loop->name."</a></span><span class='commas'></div> ");
                    }
                    if($title == 2) {
                        echo ("<div class='ewb_text_page'><a href=".get_term_link( $ewb_page_loop->term_id, "ewbrands" ).">".$ewb_page_loop->name." (".$ewbct_count. ")</a></span><span class='commas'></div> ");
                    }
                echo "</div>";
        	}
        echo "</div>";


	}
 }

add_shortcode( 'easy_woocommerce_brands_page', array( 'ewbClass', 'ewb_page_func' ) );

// Register Image Size for brands
function ewb_register_image_sizes(){
	
	add_image_size( 'ewb-brand-image-156-62', 500, 200, true);

}

add_action( 'after_setup_theme', 'ewb_register_image_sizes' );


// Custom Css for Brands Page
function ewbct_pagecss(){

	$db_ewbct_columns= esc_attr( get_option('ewbct_brand_columns') ); 

    echo "<style>.ewb-columns { width: 30%; display: inline-block; margin: 5px; padding: 0px; }.ewb_logo_page { border: 1px solid #eee; padding: 20px; min-height: 80px !important; }.ewb_text_page a { text-align: center !important; border-bottom: 0px;box-shadow: none;    color: #4c4646; }.ewb_text_page { text-align: center; padding: 10px; background: #eeeeee; }@media only screen and (max-width: 600px) {.ewb-columns { width: 100%; display: block;margin: 5px; padding: 20px 15px; }}</style>";
}

add_action( 'wp_head', 'ewbct_pagecss' );


?>