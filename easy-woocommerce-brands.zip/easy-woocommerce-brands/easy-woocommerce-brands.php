<?php
/**
 * @package Easy Woocommerce Brands
 * @version 1.1
 */
/*
Plugin Name: Easy Woocommerce Brands
Plugin URI: http://wordpress.org/plugins/product-brands/
Description: The Easy Woocommerce Brands plugin allows you to create brands for your shop. In this plugin you manage a brand can be named, described and assigned to a products.
Author: Osama Baqi
Version: 1.1
Author URI: https://osamabaqi.blogspot.com
*/

if ( file_exists( plugin_dir_path( __FILE__ ).'include/admin/brand_image_field.php' ) ) {
  include(plugin_dir_path( __FILE__ ).'include/admin/brand_image_field.php');
}
if ( file_exists( plugin_dir_path( __FILE__ ).'include/admin/ewb-settings.php' ) ) {
  include(plugin_dir_path( __FILE__ ).'include/admin/ewb-settings.php');
}
if ( file_exists( plugin_dir_path( __FILE__ ).'include/shortcode/ewb_page.php' ) ) {
  include(plugin_dir_path( __FILE__ ).'include/shortcode/ewb_page.php');
}
if ( file_exists( plugin_dir_path( __FILE__ ).'include/widget/brands-widget.php' ) ) {
  include(plugin_dir_path( __FILE__ ).'include/widget/brands-widget.php');
}

// Register Taxonomy
function ewbct_register_taxonomy() {

  $ewbct_per_val= esc_attr(get_option('ewbct_permalink'));
  if ($ewbct_per_val== "") {
      $ewbct_per_val = "brands";
  }
  else{
    $ewbct_per_val= esc_attr(get_option('ewbct_permalink'));
  }
  $labels = array(
    'name'                       => _x( 'Brands', 'Brands General Name', 'easy-woocommerce-brands' ),
    'singular_name'              => _x( 'Brand', 'Brands Singular Name', 'easy-woocommerce-brands' ),
    'menu_name'                  => __( 'Brands', 'easy-woocommerce-brands' ),
    'all_items'                  => __( 'All Items', 'easy-woocommerce-brands' ),
    'parent_item'                => __( 'Parent Item', 'easy-woocommerce-brands' ),
    'parent_item_colon'          => __( 'Parent Item:', 'easy-woocommerce-brands' ),
    'new_item_name'              => __( 'New Item Name', 'easy-woocommerce-brands' ),
    'add_new_item'               => __( 'Add New Item', 'easy-woocommerce-brands' ),
    'edit_item'                  => __( 'Edit Item', 'easy-woocommerce-brands' ),
    'update_item'                => __( 'Update Item', 'easy-woocommerce-brands' ),
    'view_item'                  => __( 'View Item', 'easy-woocommerce-brands' ),
    'separate_items_with_commas' => __( 'Separate items with commas', 'easy-woocommerce-brands' ),
    'add_or_remove_items'        => __( 'Add or remove items', 'easy-woocommerce-brands' ),
    'choose_from_most_used'      => __( 'Choose from the most used', 'easy-woocommerce-brands' ),
    'popular_items'              => __( 'Popular Items', 'easy-woocommerce-brands' ),
    'search_items'               => __( 'Search Items', 'easy-woocommerce-brands' ),
    'not_found'                  => __( 'Not Found', 'easy-woocommerce-brands' ),
    'no_terms'                   => __( 'No items', 'easy-woocommerce-brands' ),
    'items_list'                 => __( 'Items list', 'easy-woocommerce-brands' ),
    'items_list_navigation'      => __( 'Items list navigation', 'easy-woocommerce-brands' ),
  );
  $rewrite = array(
    'slug'                       => $ewbct_per_val,
    'with_front'                 => true,
    'hierarchical'               => false,
  );
  $args = array(
    'labels'                     => $labels,
    'hierarchical'               => true,
    'public'                     => true,
    'show_ui'                    => true,
    'show_admin_column'          => true,
    'show_in_nav_menus'          => true,
    'show_tagcloud'              => true,
    'rewrite'                    => $rewrite,
  );
  register_taxonomy( 'ewbrands', array( 'product' ), $args );
}


add_action( 'init', 'ewbct_register_taxonomy', 0 );